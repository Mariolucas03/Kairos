# Handoff: Rediseño del Home de Kairos — sistema "Bento"

## Resumen

Rediseño completo de la pantalla **Home** (`frontend/src/pages/Home.jsx`) y de sus 11 widgets.
El diseño aprobado por el cliente es la opción **3a** del documento de exploración.

El problema del Home actual: cada widget lleva su propio degradado saturado, borde de 2px de color,
glow fuerte y barra inferior de 12px, y **todos miden 160px de alto**. Once tarjetas gritando lo mismo
con la misma jerarquía = no hay nada que mires primero. El rediseño mantiene el color como
identificador de cada métrica pero lo reduce a una **línea de acento de 2px**, y usa el **tamaño de la
tarjeta** para crear jerarquía.

---

## Sobre los archivos de este paquete

La carpeta `referencia/` contiene **implementaciones React de referencia ya escritas** que reproducen el
diseño en el entorno real del proyecto (React + Vite + TailwindCSS + lucide-react).

No son maquetas HTML: son los mismos componentes del proyecto, reescritos. **Pueden copiarse
directamente sobre `frontend/src/`**, pero la responsabilidad de quien implemente es:

1. Verificar que la lógica de negocio y las llamadas a API siguen intactas (ver "Qué NO se toca").
2. Comprobar que compilan contra las versiones reales de los hooks/servicios del repo.
3. Ajustar cualquier detalle que dependa de datos reales que no se pudieron probar aquí.

**Fidelidad: alta (hi-fi).** Colores, tipografías, espaciados y radios son definitivos.

---

## Estructura de archivos

```
frontend/src/
├── components/
│   ├── common/
│   │   └── WidgetCard.jsx          ← NUEVO. Chasis común de todas las tarjetas.
│   └── widgets/
│       ├── StreakWidget.jsx        ← reescrito (ahora incluye el cofre diario)
│       ├── FoodWidget.jsx          ← reescrito
│       ├── MissionsWidget.jsx      ← reescrito
│       ├── SportWidget.jsx         ← reescrito
│       ├── TrainingWidget.jsx      ← reescrito (ahora incluye el volumen semanal)
│       ├── StepsWidget.jsx         ← reescrito
│       ├── SleepWidget.jsx         ← reescrito
│       ├── WeightWidget.jsx        ← reescrito
│       ├── KcalBalanceWidget.jsx   ← reescrito
│       ├── MoodWidget.jsx          ← reescrito (selector en línea)
│       └── WeeklyWidget.jsx        ← refactor: exporta useWeeklyStats + WeeklyHistoryModal
└── pages/
    └── Home.jsx                    ← reescrito
```

**No se toca nada más.** En concreto: `Header.jsx`, `Footer.jsx`, `Layout.jsx`, `HealthWidget.jsx`,
`SortableWidget.jsx`, `DailyRewardModal.jsx`, los hooks, los servicios ni el backend.

---

## El sistema visual

### Chasis de tarjeta (`WidgetCard.jsx`)

Todas las tarjetas comparten exactamente esto:

| Propiedad | Valor |
|---|---|
| Fondo | `#0a0a0c` |
| Borde | `1px solid rgba(255,255,255,0.07)` |
| Radio | `24px` |
| Línea de acento | `2px` de alto, pegada arriba, `linear-gradient(90deg, <acento>, transparent)` |
| Halo | círculo de `130px`, `blur(30px)`, opacidad `0.11`, color del acento, posición `-right-7 -bottom-9` |
| Padding | `16px` por defecto (`18px` en tarjetas de ancho completo) |
| Estado activo | `active:scale-[0.985]` |

Fuera: los degradados de fondo, los bordes de 2px de color, la barra inferior de 12px y los
`shadow-[0_0_30px_...]`.

### Tipografía

| Elemento | Estilo |
|---|---|
| Etiqueta del widget (`PASOS`, `SUEÑO`, `MISIONES`…) | `11px`, `font-black` (900), `text-zinc-300` (`#d4d4d8`), `uppercase`, `letter-spacing: 0.16em`, `line-height: 1` |
| Número principal | `30px`, `font-black`, **blanco**, `letter-spacing: -0.05em`, `line-height: 1` |
| Número en tarjetas de media altura destacadas (misiones, deporte) | `40px` |
| Unidad (`KG`, `MIN`, `H`, `KCAL`, `/5`) | `13px`, `font-black`, **color del acento del widget** |
| Sub-línea / metadato | `9px`, `font-black`, `text-zinc-500`, `letter-spacing: 0.08em`, `uppercase` |
| Fecha (cabecera) | día de la semana `9px/zinc-600/0.2em`; fecha `19px/black/blanco/-0.04em` |

**Regla de oro pedida explícitamente por el cliente:** la unidad **siempre** lleva el color de su
widget. Si el `KG` de peso es rosa, el `KCAL` de balance es acero, el `MIN` de deporte es cian, etc.
Sin excepciones.

Todo el texto lleva `not-italic`: el diseño anterior usaba cursivas, el nuevo no.

### Paleta — un tono por métrica

Exportada en `WidgetCard.jsx` como `WIDGET_ACCENTS`:

| Widget | Acento | Hex |
|---|---|---|
| Racha + cofre | naranja | `#f97316` |
| Nutrición | lima | `#a3e635` |
| Misiones | rosa-rojo | `#f43f5e` |
| Deporte | cian | `#22d3ee` |
| Rutina gym + volumen | oro | `#eab308` |
| Pasos | bronce | `#c9a227` |
| Sueño | acero | `#64748b` |
| Peso | rosa | `#FF61D2` |
| Balance kcal | gris azulado | `#94a3b8` |
| Ánimo | rosa claro | `#FE90AF` |
| Histórico volumen (modal) | azul grisáceo | `#8ba3c9` |

Excepción: si `FoodWidget` supera el límite de kcal, su acento pasa a `#ef4444`.

Colores de estado (comunes): positivo `#4ade80`, negativo `#f87171`, neutro `#a1a1aa`.

### Rejilla

`grid grid-cols-4 gap-3 grid-flow-dense px-4 pt-[18px] pb-24`

Sin `auto-rows` fijo: cada tarjeta define su alto. Reparto:

| Widget | Columnas | Alto |
|---|---|---|
| Racha + cofre | 4 | auto |
| Nutrición | 4 | auto (~152px por el anillo) |
| Misiones | 2 | `min-h-[124px]` |
| Deporte | 2 | `min-h-[124px]` |
| Rutina gym + volumen | 4 | auto |
| Pasos / Sueño / Peso / Balance | 2 | `min-h-[116px]` |
| Ánimo | 4 | auto |

---

## Cambios de estructura (aprobados por el cliente)

### 1. La cabecera de perfil no cambia

`Header.jsx` (avatar + marco + mascota, badge de nivel, barra de XP, anillo de vida, monedas y fichas)
se queda **exactamente como está**. El cliente lo pidió así explícitamente.

### 2. Nueva fila de página bajo la cabecera

Sustituye al antiguo `Hola, <usuario>` + fecha + botones de cofre y ajustes:

- Izquierda: día de la semana en 9px gris, y debajo la fecha en 19px black blanco.
- Derecha: **solo** el icono de ajustes (`Settings`, 21px, `text-zinc-500`).
- Se elimina el saludo "Hola, ari" (era ruido: el nombre ya está en la cabecera).
- Se elimina el botón de cofre suelto → pasa a la tarjeta de Racha.

### 3. Cofre diario → dentro de la tarjeta de Racha

`StreakWidget` recibe dos props nuevas:

```jsx
<StreakWidget
  streak={user?.streak?.current}
  onOpenChest={openCalendar}       // misma función del hook useDailyRewards
  claimed={hasClaimedToday()}
/>
```

El botón del cofre mantiene el `animate-pulse` cuando está sin reclamar y se apaga (gris) cuando ya
se ha reclamado. **La lógica de recompensas no se toca**: `DailyRewardModal`, `claimReward`,
`closeModal` y `claiming` siguen igual en `Home.jsx`.

### 4. Volumen semanal → dentro de la tarjeta de Rutina Gym

El widget `weekly` deja de ser una tarjeta independiente. En su lugar:

- `WeeklyWidget.jsx` se refactoriza y exporta:
  - `useWeeklyStats()` — el `useEffect` con el `setTimeout(500)` y el `GET /gym/weekly`. Lo llama `Home.jsx`.
  - `WeeklyHistoryModal({ onClose })` — el modal de histórico con las pestañas de músculo. Lo abre `TrainingWidget`.
  - `export default` — la tarjeta suelta, conservada por si se quiere volver a mostrar aparte.
- `TrainingWidget` recibe `weeklyVolume` y `weeklyPercentage`, los pinta a la derecha, y al tocar ese
  bloque abre `WeeklyHistoryModal`. Tocar el resto de la tarjeta abre el detalle del entreno de hoy.

**Migración de localStorage obligatoria** (ya implementada en `Home.jsx`): las claves guardadas
`home_widgets_order` y `home_widgets_config` de usuarios existentes contienen `'weekly'` y `'gains'`.
Hay que filtrarlas y añadir las que falten:

```js
const merged = saved.filter(key => key !== 'gains' && key !== 'weekly');
DEFAULTS_ORDER.forEach(k => { if (!merged.includes(k)) merged.push(k); });
```

Sin esto, `SortableContext` recibe un id (`weekly`) que ya no se renderiza y el drag&drop se rompe.

### 5. Ánimo: selector en línea

Antes había que abrir un modal para registrar el ánimo. Ahora las 5 caras están en la propia
tarjeta (34px cada una, `min-h` de 44px cumplida por el padding de la tarjeta) y se registra de un
toque. El modal sigue existiendo y se abre tocando la etiqueta "ÁNIMO".

### 6. Otros cambios menores de contenido

- **Pasos**: ahora muestra `8.432 /10K` en vez de solo el número, más barra de progreso hacia la meta.
- **Sueño**: `7,0 H` (un decimal) más barra hacia las 8h.
- **Peso**: añade una sub-línea de tendencia (`−0,4 DESDE EL INICIO`) calculada desde `history`.
  Si `history` está vacío muestra `SIN HISTÓRICO`.
- **Balance**: el número se pinta verde cuando hay déficit, y la sub-línea dice `DÉFICIT · BASAL ON/OFF`.
- **Deporte**: sub-línea con `NOMBRE · N KCAL` y, si hay más sesiones, ` · +N`.
- **Nutrición**: el desglose por comidas (desayuno / comida / merienda / cena) pasa del modal a la
  propia tarjeta, con barras y kcal por comida, y `RESTAN N` arriba a la derecha.
- **Misiones**: la barra se convierte en segmentos (uno por misión, máx. 8).

---

## Qué NO se toca (crítico)

Ninguna funcionalidad ni dato puede perderse. Todo esto debe seguir funcionando igual:

- **Drag & drop** de widgets (`@dnd-kit`, `SortableWidget`, `PointerSensor`/`TouchSensor`, `rectSortingStrategy`).
- **Modo organizar** y su persistencia en `home_drag_enabled`.
- **Visibilidad de widgets** desde Ajustes y su persistencia en `home_widgets_config`.
- **`SmartWidgetWrapper`** tal cual (distingue scroll de tap en móvil).
- Todos los **modales** de cada widget: historial de misiones, detalle de nutrición por comidas,
  detalle de gym con pestañas multi-sesión y volumen, detalle de deporte, gráfica de peso con
  puntos interactivos, y el modal de balance con el **toggle de metabolismo basal** + formulario de
  edad/altura/género (`PUT /users/physical-stats`, `localStorage.includeBMR`).
- **`useDailyLog`**, **`useDailyRewards`**, **`useSmoothMount`**, `registerPush`, `Toast`, `LoadingScreen`.
- El cálculo de kcal quemadas en `Home.jsx` (`sportWorkouts` + `gymWorkouts`).
- El mapeo de comidas `DESAYUNO / COMIDA / MERIENDA / CENA / SNACK` → `breakfast / lunch / merienda / dinner / snacks`.

---

## Estado y datos

Sin cambios en el modelo de datos ni en el backend. El único fetch que se mueve de sitio es
`GET /gym/weekly`: antes lo hacía `WeeklyWidget` al montarse, ahora lo hace `Home.jsx` a través de
`useWeeklyStats()` y lo pasa por props a `TrainingWidget`. Mismo endpoint, misma respuesta
(`{ currentVolume, percentage }`), mismo retardo de 500ms.

Props nuevas:

| Componente | Prop | Tipo | Origen |
|---|---|---|---|
| `StreakWidget` | `onOpenChest` | `() => void` | `openCalendar` de `useDailyRewards` |
| `StreakWidget` | `claimed` | `boolean` | `hasClaimedToday()` |
| `TrainingWidget` | `weeklyVolume` | `number` | `useWeeklyStats().stats.currentVolume` |
| `TrainingWidget` | `weeklyPercentage` | `number` | `useWeeklyStats().stats.percentage` |

---

## Assets

Ninguno nuevo. Se siguen usando los que ya están en `public/`:
`assets/icons/moneda.png`, `ficha.png`, `xp.png`, `corazon.png`, los avatares, marcos y mascotas.
Iconografía: `lucide-react`, ya instalado.

---

## Cómo aplicarlo

1. Copiar `referencia/src/components/common/WidgetCard.jsx` → `frontend/src/components/common/`.
2. Sobrescribir los 11 widgets y `Home.jsx` con los de `referencia/`.
3. `npm run dev` y comprobar, en este orden:
   - El Home carga y se ven las 10 tarjetas.
   - El cofre abre el calendario de recompensas y se apaga tras reclamar.
   - El volumen semanal aparece en la tarjeta de gym y abre el histórico.
   - Cada tarjeta abre su modal correspondiente.
   - Ajustes → Organizar → arrastrar y soltar, y recargar para ver que el orden persiste.
   - Ajustes → Visibilidad → apagar y encender widgets.
   - Con `localStorage` de un usuario antiguo (con `weekly` y `gains` guardados) no debe romperse nada.
4. Si algo del layout no cuadra en pantallas pequeñas (< 360px), lo primero a tocar es
   `min-h-[116px]` / `min-h-[124px]` en `WIDGET_LAYOUT` dentro de `Home.jsx`.

---

## Siguiente fase (aún no diseñada en detalle)

El mismo sistema está pensado para extenderse a Gym, Comidas, Misiones, Social y Mercado.
No implementar todavía: primero validar el Home en producción.
