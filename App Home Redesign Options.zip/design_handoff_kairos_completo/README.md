# Handoff: rediseño completo de Kairos — sistema "Bento"

Extensión del rediseño del Home (en `home/`) a **toda la app**.
Mismo sistema visual, cero cambios de estructura o de funcionalidad: **esto es solo estilo.**

El cliente lo dijo literalmente: *"nada de momento solo el estilo"*.

---

## Cómo usar este paquete

1. **Lee primero `home/README.md`** (el paquete del Home, ya aprobado). Define el sistema completo:
   chasis de tarjeta, tipografía, paleta, rejilla. Todo lo de aquí lo hereda, y en `home/referencia/`
   están sus 13 archivos `.jsx` ya escritos.
2. Este README añade lo específico de cada pantalla.
3. `prototipo/Kairos App.dc.html` es el diseño renderizado de las 11 pantallas. Ábrelo en el
   navegador para ver exactamente el resultado esperado.

Cada pantalla de este documento se diseñó **leyendo su archivo real** del repositorio. Los datos,
etiquetas y estados que aparecen son los que el código ya maneja. Aun así:

- **Este documento manda en lo visual**: colores, tamaños, pesos, espaciados, radios, jerarquía.
- **El código actual manda en todo lo demás**: props, hooks, endpoints, estado, navegación, modales,
  validaciones. Lee cada página antes de tocarla y **conserva su lógica íntegra**.

---

## Recordatorio del sistema (resumen)

| Elemento | Valor |
|---|---|
| Fondo de pantalla | `#050506` (el actual es `bg-black`, se mantiene) |
| Superficie de tarjeta | `#0a0a0c` |
| Borde | `1px solid rgba(255,255,255,0.07)` |
| Radio de tarjeta | `24px` |
| Línea de acento | `2px` arriba, `linear-gradient(90deg, <acento>, transparent)` |
| Halo | círculo `130px`, `blur(30px)`, opacidad `0.11`, color del acento |
| Rejilla | `grid-cols-4 gap-3 px-4` |
| Etiqueta | `11px` / `900` / `#d4d4d8` / `uppercase` / `tracking .16em` |
| Número | `30px` / `900` / blanco / `tracking -.05em` |
| Unidad | `13px` / `900` / **color del acento** |
| Sub-línea | `9px` / `900` / `#71717a` / `uppercase` / `tracking .08em` |
| Cabecera de página | antetítulo `9px/#52525b/.2em` + título `26px/900/blanco/-.045em/uppercase` |

Nada de cursivas (`not-italic` en todo — el diseño actual usa `italic` en los títulos, se elimina),
nada de degradados de fondo, nada de barras inferiores de color, nada de `shadow-[0_0_30px]`.

### Pestañas

Contenedor: `flex gap-1 mx-4 mt-[18px] bg-[#0a0a0c] border border-white/[0.07] rounded-[18px] p-1`
Activa: `flex-1 py-2.5 rounded-[14px]` + fondo del acento + texto negro (blanco si el acento es oscuro)
Inactiva: igual pero `text-zinc-500`, sin fondo
Texto: `11px` / `900` / `tracking .1em` / `uppercase`. Con 4+ pestañas: radio `12px`, `py-[9px]`, `10px`.

### Modales

`bg-[#09090b]`, `border border-white/10`, `rounded-[40px]`, `p-6`, tras `bg-black/90 backdrop-blur-md`,
línea de acento de `1px` arriba, título `text-2xl font-black uppercase tracking-tighter` con la
fórmula **VERBO + SUSTANTIVO en color** («DETALLE **GYM**»). Cierre: `bg-zinc-900 p-2 rounded-full`.

**Todos los modales existentes se conservan.** Solo cambia su piel.

---

## Acentos por sección

| Pantalla | Acento | Hex |
|---|---|---|
| Zona de entreno | oro | `#eab308` |
| Entreno en curso | oro | `#eab308` |
| Comidas | lima | `#a3e635` |
| Misiones | rosa-rojo | `#f43f5e` |
| Feed social | oro | `#eab308` |
| Mercado | oro | `#eab308` |
| Mochila | cian | `#22d3ee` |
| Arcade | uno por juego | — |
| Login | oro | `#eab308` |
| Registro | azul | `#3b82f6` |
| Ajustes | acero | `#94a3b8` |

Dentro de una lista heterogénea (rutinas, categorías, juegos, objetos) cada elemento lleva su propio
tono: eso es lo que da ritmo. Lo que **no** se hace es poner dos colores en degradado en una tarjeta.

---

## Pantalla por pantalla

### 1. Zona de entreno (`pages/Gym.jsx`) — `5a`

- Cabecera: antetítulo `SUPERA TUS LÍMITES` + título `ZONA DE ENTRENO` + icono de ajustes.
- Pestañas `GYM / CUERPO / OTROS` con icono (`Dumbbell`, `PersonStanding`, `Activity`), acento oro.
- **Botón "Nueva rutina"**: sólido oro, texto negro, radio `20px`, icono `Plus` `stroke-width 3` +
  texto `11px/900/.14em`.
- Cabecera de lista: `MIS RUTINAS` + `DESLIZA PARA EDITAR O BORRAR` (el swipe existente se conserva).
- **Filas de rutina** (ancho completo): cuadrado de `48px` radio `16px` con la inicial en `20px/900`
  sobre el acento al 14%, nombre en `17px/900/uppercase`, sub-línea `N EJERCICIOS`, y botón circular
  de `44px` con `Play` relleno.
- **Rutina en curso**: borde de la tarjeta `rgba(234,179,8,.3)`, sub-línea `N EJERCICIOS · EN CURSO`
  en oro, y el botón cambia a icono `Activity` gris con `animate-pulse` (no se puede volver a lanzar).
- Un tono por rutina asignado por orden, estable (oro, azul, verde, violeta…).
- **NO hay tarjeta de volumen semanal aquí** — el volumen vive en el widget del Home.

### 2. Entreno en curso (`components/gym/ActiveWorkout.jsx`) — `5b`

- Cabecera: antetítulo `RUTINA EN CURSO`, título con el nombre de la rutina, y a la derecha
  `ChevronDown` (minimizar) + `X` (cerrar).
- **Barra de sesión**: cronómetro en `44px` monoespaciado con `font-variant-numeric: tabular-nums`
  (para que no baile al pasar los segundos), y a la derecha el contador de series hechas.
- **Selector de intensidad**: fila con etiqueta `INTENSIDAD` + tres opciones `BAJA / MEDIA / ALTA`
  en el patrón de pestañas compacto (radio `14px` exterior, `11px` interior).
- **Una tarjeta por ejercicio**: cabecera con nombre, sub-línea `MÚSCULO · PR N KG × N`, y a la
  derecha `RefreshCw` (sustituir) + `Plus` (añadir serie).
  - Cada serie: número de serie, dos inputs (peso × reps) y botón de confirmación de `34px` radio `11px`.
  - Serie hecha: inputs en `#71717a`, botón sólido oro con `Check`.
  - Serie activa: fondo `rgba(234,179,8,.07)`, inputs con borde `rgba(234,179,8,.45)` y texto blanco.
  - Serie pendiente: todo en `#3f3f46`, botón vacío con borde.
- **Añadir foto**: tarjeta con `border-dashed` e icono `Camera`.
- **Terminar entreno**: botón sólido oro de ancho completo con icono `Save`.
- **Barra flotante de descanso**: `position: fixed` sobre la barra de navegación
  (`bottom: 98px`, `left/right: 16px`), `bg-[#0a0a0c]/97` + `backdrop-blur`, radio `24px`.
  Contiene la cuenta atrás en `30px` monoespaciado, el ajuste de tiempo fijo y el botón `SALTAR`
  (sólido blanco, texto negro). Solo visible mientras hay descanso activo.

### 3. Comidas (`pages/Food.jsx`) — `5c`

- Antetítulo con el objetivo (`OBJETIVO 2.400 KCAL`), título `COMIDAS`, ajustes a la derecha.
- **Tarjeta de macros** (radio `26px`): anillo de `112px` con `stroke-width 9` a la izquierda
  (kcal en `27px` + `KCAL` en lima), y a la derecha las cuatro barras de macros.
  - Cada barra: etiqueta `44px` de ancho, barra de `5px`, valor `actual/objetivo` con el objetivo
    en el color del macro.
  - Colores de macro: proteína `#3b82f6`, carbos `#facc15`, grasa `#f87171`, fibra `#22c55e`.
  - Arriba a la derecha: `RESTAN N` en lima (o `+N` en rojo `#ef4444` si se pasa; en ese caso el
    acento de toda la tarjeta pasa a rojo).
- **Una tarjeta por comida**: cabecera con nombre, kcal (`20px`) + `KCAL · N ITEMS` en su tono, y
  botón `+` de `38px` radio `13px`. Debajo, tras `border-top`, la lista de alimentos: nombre
  `12px/700`, fila de macros en `9px/900` con los colores de macro, y kcal a la derecha.
- Tonos por comida: desayuno `#65a30d`, comida `#84cc16`, merienda `#a3e635`, cena `#bef264`,
  snacks `#d9f99d`.
- **Comida vacía**: `border-dashed rgba(255,255,255,.12)`, etiqueta en `#71717a` y sub-línea
  `SIN ALIMENTOS · TE QUEDAN N KCAL`.
- Se conserva el mapeo `DESAYUNO / COMIDA / MERIENDA / CENA / SNACK` del backend.

### 4. Misiones (`pages/Missions.jsx`) — `5d`

- Antetítulo `HASTA HOY 23:59`, título `MISIONES`, y a la derecha `EyeOff` (ocultar completadas) y
  `Plus` en el acento.
- Pestañas `DIARIA / SEMANA / MES / AÑO`, acento `#f43f5e`.
- **Tarjeta de progreso**: etiqueta + barra segmentada (un segmento por misión) y `3/5` a la derecha
  (`28px` blanco + `/5` en el acento).
- **Una tarjeta por misión**:
  - Cabecera: icono de tipo (`Repeat` recurrente, `Flag` puntual, `Users` reto social) en el color de
    la misión + nombre como etiqueta.
  - Número: `actual/objetivo` con el objetivo en `#3f3f46` y la unidad en el color de la misión.
  - Chip de dificultad arriba a la derecha: `FÁCIL` verde, `MEDIA` azul, `DIFÍCIL` rosa, `ÉPICA`
    violeta — fondo al 12%, borde al 30%, `9px/900/.1em`, radio `8px`.
  - Botón `+` de `32px` radio `11px` en las misiones de incremento manual.
  - Barra de `6px`. En retos sociales, **dos segmentos** (tu color + el del rival) y leyenda con
    puntos de `7px` debajo.
  - Pie tras `border-top`: recompensas con los PNG reales de `public/assets/icons`
    (`xp.png`, `moneda.png`, `ficha.png`, `corazon.png`) a `20px`, número en `12px/900` delante.
    La penalización de vida a la derecha en rojo.
  - Completada: opacidad `.55`, etiqueta tachada, chip `HECHO` gris.

### 5. Feed social (`pages/Social.jsx` + `components/social/WorkoutPostCard.jsx`) — `5e`

- **Cabecera en dos filas** (como ya está en el código, para que no se parta en móvil):
  fila 1 el título `FEED` con icono `Rss` en oro + subtítulo `ENTRENOS DE TUS AMIGOS` truncado;
  fila 2 los **5 botones de acción** a ancho igual (`flex-1`), chasis de tarjeta radio `16px`,
  icono de `18px` en `#d4d4d8`: `Search`, `Users` (amigos), `Shield` (clan), `Trophy` (ranking),
  `Mail` (buzón). El buzón lleva el contador rojo (`min-w-[17px] h-[17px]`, borde del fondo).
  - Al abrir la búsqueda, la fila de botones se sustituye por el campo expandible: borde
    `rgba(234,179,8,.5)`, radio `16px`, lupa oro a la izquierda y `X` (o `Loader2`) a la derecha.
- **Publicación a sangre** (`-mx-4`, sin marco ni esquinas), separada por
  `border-bottom: 4px solid rgba(255,255,255,.2)` — se conserva tal cual:
  - Cabecera: avatar de `40px` con el `frame` superpuesto a `52px` desplazado `-6px`, nombre en
    `14px/900/uppercase`, chip de nivel (`getLevelStyle`) + tiempo relativo en `9px/700`, y a la
    derecha el cuadrado de tipo (`34px` radio `11px`): `Dumbbell` oro si es gym, `Activity` lima si no.
  - Titular **encima** del carrusel: nombre de la rutina en `18px/900/uppercase` y fila de métricas
    (`Timer` azul + min, `Flame` naranja + kcal, `Dumbbell` oro + ejercicios, o `MapPin` cian + km).
  - **Carrusel cuadrado** (`aspect-square`) con hasta 3 diapositivas: foto, mapa corporal, ejercicios.
    - Cinta de récord arriba a la izquierda: sólido oro, `Trophy` + `RÉCORD PERSONAL` / `N RÉCORDS`.
    - Puntitos abajo centrados sobre `bg-black/60 backdrop-blur`, el activo `w-3` blanco.
    - Diapositiva de ejercicios: el ejercicio con PR va en oro (borde `2px #eab308`, degradado cálido
      y `shadow-[0_0_18px_-4px_rgba(234,179,8,.65)]`), chip `PR` sólido oro, series como chips
      (`9px/700`), y las series tipo `D` en morado. Debajo, la línea de récord con el peso anterior.
  - Acciones: `Heart` de `24px` (rojo relleno si te gusta) + contador, y `MessageCircle` de `24px`
    (azul si está abierto) + contador.
  - Comentarios desplegables: avatar de `28px`, burbuja `bg-zinc-900 rounded-2xl`, y el campo de
    entrada redondo con botón de envío azul de `38px`.
- **Cargar más**: botón con chasis de tarjeta, `ChevronDown` + `CARGAR MÁS`.
- Se conservan los tres estados vacíos distintos (error de red con `WifiOff` + reintentar, sin
  amigos con `Users`, sin publicaciones con `Dumbbell`) y el `LoadingScreen` de primera carga.
- Ranking, Amigos y Clanes son **páginas propias** (`pages/social/`), no pestañas.

### 6. Mercado (`pages/Shop.jsx`) — `5f`

- Antetítulo `GASTA TU FORTUNA`, título `MERCADO`. **Sin contadores de moneda en la cabecera**: ya
  están en el `Header.jsx` global.
- Pestañas `TIENDA / MOCHILA` con icono.
- **Casa de cambio**: tarjeta de ancho completo, icono `ArrowRightLeft` en violeta, y la conversión
  escrita como `100 FICHAS → 1 MONEDA` con los números en blanco `18px` y las unidades en su color.
- **Categorías**: rejilla de 2 columnas, tarjetas de `112px`, icono de `24px` centrado arriba en su
  color y la etiqueta centrada debajo. **Sin contadores de existencias** (no vienen del backend).
  Ocho categorías: Premios `#eab308`, Pociones `#ef4444`, Avatar `#3b82f6`, Marcos `#22d3ee`,
  Temas `#a3e635`, Cofres `#f97316`, Mascotas `#FE90AF`, Títulos `#facc15` (icono `Crown`).

### 7. Mochila (`5g`)

- Misma cabecera y pestañas que Mercado, con `MOCHILA` activa (acento cian).
- **Drill-down por categoría**: cuando entras en una, aparece una fila con botón de vuelta
  (`ChevronLeft`, círculo de `38px`) + el nombre de la categoría en `19px/900/uppercase`.
- **Objetos**: rejilla de 2 columnas, tarjetas de `min-h-[160px]` centradas: icono de `34px` arriba,
  nombre en `10px/900/uppercase` centrado, **rareza** debajo en `7px/900/.15em` en su color, y el
  chip de estado abajo (`X 3`, `EN PROPIEDAD`).
- **El borde de la tarjeta lo marca la rareza**, no la categoría:
  común `#27272a`, raro `rgba(59,130,246,.4)` / texto `#60a5fa`, épico `rgba(168,85,247,.5)` /
  `#c084fc`, legendario `rgba(234,179,8,.6)` / `#facc15`. El halo sube de `.14` a `.18` con la rareza.

### 8. Arcade (`pages/Games.jsx`) — `5i`

- Antetítulo `ZONA DESBLOQUEADA` en verde con `CheckCircle2` (o el estado de bloqueo real), título
  `ARCADE`. **Sin contador de fichas** (está en el Header) y **sin tarjeta de resumen de ganancias**.
- **Rejilla de 2 columnas** con los 7 juegos, tarjetas de `140px` centradas: círculo de `52px`
  (`bg-[#18181b]` + borde al 6%) con el icono en su color, nombre en `13px/900/uppercase` y
  subtítulo en la sub-línea.
- El borde de cada tarjeta es el color del juego al 30%:

| Juego | Subtítulo | Icono | Color |
|---|---|---|---|
| Ruleta | Casino Royal | `Disc` | `#f87171` |
| Blackjack | Suma 21 | `Spade` | `#4ade80` |
| Neon Slots | Jackpot | `Zap` | `#e879f9` |
| Dados | High / Low | `Dices` | `#60a5fa` |
| Rasca | Premio rápido | `Ticket` | `#c084fc` |
| La Torre | Sube o piérdelo | `Building2` | `#34d399` |
| Fortuna | Giro diario | `CircleDollarSign` | `#facc15` |

- **El bloqueo del arcade depende del 75% de las misiones diarias**, no del nivel. Cuando está
  bloqueado, el antetítulo lo indica y las tarjetas van al 55% de opacidad con `Lock`.

### 9. Login (`pages/Login.jsx`) — `5j`

- **Sin barra de navegación.** Contenido centrado, `px-6`. Es una **página independiente** del
  registro: no hay pestañas, y **no hay botones de Google ni de Apple**.
- **Marca**: cuadrado de `64px` radio `20px` (`bg-yellow-500/12`, borde al 30%) con `Swords` de
  `30px`; debajo `KAIROS` en `40px/900/-.055em` y `SISTEMA DE ACCESO` en `9px/900/.24em/#52525b`.
- **Tarjeta "Identificarse"** (radio `28px`, acento oro): cabecera con `UserCheck` + etiqueta, y
  dentro los campos.
  - Campo: etiqueta `9px/900/.14em/#52525b` encima; caja `bg-black`, borde al 9%, radio `16px`,
    `py-[14px]`, icono de `17px` a la izquierda y texto `14px/600`.
  - Campo enfocado: borde `rgba(234,179,8,.45)` y el icono en oro.
  - `USUARIO O ALIAS` (icono `User`) y `CONTRASEÑA` (icono `Lock` + `Eye` para mostrar).
- **Botón Entrar**: sólido oro, radio `18px`, `py-4`, `12px/900/.16em` + `ArrowRight`.
- Pie: `¿AÚN NO TIENES EXPEDIENTE?` en sub-línea y `SOLICITAR ACCESO` en `10px/900/.16em` oro.

### 10. Registro (`pages/Register.jsx`) — `5j2`

Misma estructura que el login, con **acento azul `#3b82f6`** para diferenciarlo:

- Marca: cuadrado azul con `UserPlus`, título `NUEVO RECLUTA` en `30px/900/uppercase` y
  `EMPIEZA TU PARTIDA` como sub-línea.
- **Tarjeta "Crear expediente"** con `FilePlus`, y tres campos:
  `ALIAS` (con el contador `MÁX. 8` alineado a la derecha de su etiqueta — el límite real del
  código), `CORREO` y `CONTRASEÑA`.
- **Botón Confirmar**: sólido azul, texto blanco, `CONFIRMAR` + `Check`.
- Pie: `¿YA TIENES EXPEDIENTE?` + `INICIAR SESIÓN` en azul.

### 11. Ajustes (`pages/Settings.jsx`) — `5k`

**Ojo: esta pantalla es privacidad de perfil, no configuración del Home.** La visibilidad de
widgets y el modo organizar viven en el modal de ajustes del Home (ver `home/README.md`).

- Cabecera con el `BackButton` existente (círculo de `38px`) + antetítulo `PRIVACIDAD Y PERFIL` y
  título `AJUSTES`.
- **`TU PERFIL`**: fila con avatar de `46px` (con mascota), nombre como etiqueta, sub-línea
  `VER MI PERFIL PÚBLICO` y `ChevronRight` — navega al perfil público.
- **Descripción**: tarjeta con etiqueta `DESCRIPCIÓN` y el contador `62 / 150` a la derecha en
  `#3f3f46`; el textarea es `bg-black`, borde al 9%, radio `16px`, `min-h-[78px]`, texto `13px/600`.
- **`1 · QUIÉN PUEDE VER TU PERFIL`**: el número va en un cuadrado de `20px` radio `7px` con
  `bg-[#94a3b8]/14`. Debajo, tarjeta con acento verde: icono `Globe` en cuadrado de `44px`,
  etiqueta `CUENTA PÚBLICA` (o `CUENTA PRIVADA`), sub-línea de estado en verde, e interruptor.
  Tras `border-top`, la nota con icono `Info` en `11px/600/#71717a`.
  - Interruptor grande: `46×28`, apagado `bg-[#18181b]` + borde al 9% + bola `20px` `#3f3f46`;
    encendido fondo del acento + bola negra a la derecha.
- **`2 · QUÉ ENSEÑAS DE TI`**: una tarjeta con cuatro filas separadas por
  `border-bottom rgba(255,255,255,.05)`. Cada fila: cuadrado de `34px` radio `11px` con el icono en
  su color, nombre en `12px/700`, sub-línea descriptiva, e interruptor pequeño (`38×22`, bola `16px`).
  - Entrenos `#eab308` (`Dumbbell`) · Cuerpo `#FF61D2` (`PersonStanding`) ·
    Comida `#a3e635` (`Utensils`) · Misiones `#f43f5e` (`Target`).
- **Guardar cambios**: botón sólido oro con `Save`. Mantener el comportamiento actual de quedar
  deshabilitado mientras no haya cambios (opacidad reducida y sin pulsación).
- **Cerrar sesión**: `bg-[rgba(69,10,10,.22)]`, borde `rgba(239,68,68,.3)`, texto `#f87171`.
- Debajo, el ID de usuario en `10px` monoespaciado `#3f3f46` centrado.

---

## Barra de navegación

Se mantiene la actual (`Footer.jsx`) **sin cambios de estructura**: 4 destinos, botón central
elevado de `56px` con degradado oro y borde negro de `4px`. Solo revisar que el activo lleve
`scale(1.1)` + `drop-shadow(0 0 8px rgba(234,179,8,.4))` y los inactivos `#71717a` con etiqueta
`#52525b`.

En el prototipo se ve como componente aparte (`prototipo/KairosNav.dc.html`) solo para poder
repetirlo en las pantallas; **no crees un componente nuevo en el proyecto**.

---

## Qué NO se toca

- Ninguna ruta, ningún endpoint, ningún hook, ningún store.
- Ningún modal se elimina ni se fusiona (salvo las dos fusiones ya aprobadas del Home: cofre dentro
  de Racha, volumen semanal dentro de Rutina Gym).
- Drag & drop del Home, persistencia en `localStorage`, `SmartWidgetWrapper`, `SortableWidget`.
- `Header.jsx` (avatar, marco, mascota, XP, vida, monedas, fichas) se queda exactamente igual.
- La paginación del feed, el `useSWR` de amigos/notificaciones, `useSocialBadge`, `InboxModal`,
  `ZoomableImage`, `BodyMap`, `getLevelStyle`, `timeAgo`, `customAnimationsStyle`.
- El carrusel de la publicación y su cálculo de diapositiva activa por scroll.
- Backend, esquemas y modelos: intactos.

---

## Orden de trabajo recomendado

1. `Gym.jsx` — es la pantalla con más patrones nuevos (pestañas + filas con botón de acción).
2. `Food.jsx` — reutiliza el anillo y las barras que ya existen en `FoodWidget`.
3. `Missions.jsx` — el patrón de tarjeta de misión ya está en `MissionsWidget`.
4. `Shop.jsx` + mochila — rejilla de categorías, objetos y bordes por rareza.
5. `Games.jsx`, `Login.jsx`, `Register.jsx`, `Settings.jsx` — las cuatro más rápidas.
6. `WorkoutPostCard.jsx` y `Social.jsx`.
7. `ActiveWorkout.jsx` al final: es el que más lógica de estado tiene (cronómetro, series,
   descanso, intensidad, foto).

Después de cada pantalla: `npm run dev`, recorrer todos sus modales y comprobar que ningún dato ha
desaparecido respecto a la versión anterior.

---

## Assets

Ninguno nuevo. Iconografía `lucide-react`. PNG de economía ya en `public/assets/icons/`
(`moneda`, `ficha`, `xp`, `corazon`), avatares en `public/avatars/`, marcos en `public/frames/`,
mascotas en `public/pets/`.
